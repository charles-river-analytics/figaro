package com.cra.appril.birdmigration.test

import com.cra.figaro.language.Chain
import scala.collection.mutable.ListBuffer
import com.cra.figaro.language.ElementCollection
import com.cra.figaro.language.Element
import com.cra.figaro.language.Apply
import com.cra.appril.birdmigration.elements.Counter
import com.cra.figaro.library.atomic._
import scala.collection._
import com.cra.figaro.language.Constant
import scala.math.{ exp, pow }
import com.cra.figaro.library.atomic.discrete.Poisson
import com.cra.figaro.language.Inject
import com.cra.appril.birdmigration.elements.CounterAbstraction
import com.cra.figaro.algorithm.Abstraction
import JSci.maths.ExtraMath.factorial
import scala.math._
import com.cra.figaro.algorithm.{ AbstractionScheme, Abstraction }
import com.cra.appril.birdmigration.elements.Multinomial
import com.cra.figaro.algorithm.factored.beliefpropagation.BeliefPropagation
import com.cra.figaro.library.atomic.discrete.Binomial
import com.cra.figaro.algorithm.factored.VariableElimination

object ConstraintTest {
  
    val factorialSizeLimit = 14

  def logFactorial(n: Int): Double = {

    if (n < 0) {
      throw new IllegalArgumentException
    }
    if (n == 0 || n == 1) {
      0.0;
    }
    if (n <= factorialSizeLimit) {
      var z: Long = 1;
      var x: Long = 1;
      for (i <- 2 to n) {
        x += 1;
        z *= x;
      }
      return Math.log(z);
    } else {
      var x = (n + 1).toDouble;
      var y = 1.0 / (x * x);
      var z = ((-(5.95238095238E-4 * y) + 7.936500793651E-4) * y -
        2.7777777777778E-3) * y + 8.3333333333333E-2;
      z = ((x - 0.5) * Math.log(x) - x) + 9.1893853320467E-1 + z / x;
      return z;
    }
  }

  
  //def density(d: Double) = {
//    val diff = d - mean
    //val exponent = -(diff * diff) / (2.0 * variance)
    //normalizer * exp(exponent)
//  }
  
  def normalDensity(d: Double, mean: Double, stdDev: Double) = {
    val variance = stdDev*stdDev
    val normalizer = 1.0 / sqrt(2.0 * Pi * variance)
    val diff = d - mean
    val exponent = - (diff * diff) / (2.0 * variance)
    normalizer * exp(exponent)
  }
  
  //Normpdf(n.toDouble, birdsObservedInCell.toDouble, stddev)
  
  /*
  def poissonDensity(lambda: Double, k: Int) = {
    val expMinusLambda = exp(-lambda)
    val result = pow(lambda, k) / factorial(k) * expMinusLambda
    result
  }
  */
  //A lot faster than the original
  def poissonDensity(lambda: Double, k: Int) = {
    val lambdaToK = pow(lambda, k)
    val logLambdaToK = Math.log(lambdaToK)
    val logFactorialK = logFactorial(k)
    val logResult = (logLambdaToK - logFactorialK - lambda)
    val result = Math.exp(logResult)
    result
  }
  
  def constraintTest1 = {

    val p1 = discrete.Uniform(0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95)
    val p2 = discrete.Uniform(0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95)
    val p3 = discrete.Uniform(0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95)
    val p4 = discrete.Uniform(0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95)
    
    val x11 = 0.498884119
    val x12 = 0.894427191
    val x13 = -0.948683298
    val x14 = 0
   
    val x21 = 0.340641292
    val x22 = 1
    val x23 = -0.707106781
    val x24 = 0
    
    val x31 = 0.911466171	
    val x32 = 0.998274373	
    val x33 = -0.707106781
    val x34 = 0
    
    val x41 = 0.700171152	
    val x42 = 0.928476691	
    val x43 = -0.447213595
    val x44 = 0

    val start1 = Constant(50)
    val start2 = discrete.Uniform(0,1)
    
    val a1 = Apply(p1, p2, p3, p4, (b1: Double, b2: Double, b3: Double, b4: Double) => {

        val numerator = math.exp(
            (b1 * x11) +
            (b2 * x12) +
            (b3 * x13) +
            (b4 * x14))

        var denominator = 0.0

          denominator += math.exp(
        		  (b1 * x11) +
            (b2 * x12) +
            (b3 * x13) +
            (b4 * x14))
            
                  denominator += math.exp(
        		  (b1 * x21) +
            (b2 * x22) +
            (b3 * x23) +
            (b4 * x24))

        val result = numerator / denominator
        //println(result)
        result
      })
    a1.addPragma(Abstraction(10)) 
     
    val a2 = Apply(p1, p2, p3, p4, (b1: Double, b2: Double, b3: Double, b4: Double) => {

        val numerator = math.exp(
            (b1 * x21) +
            (b2 * x22) +
            (b3 * x23) +
            (b4 * x24))

        var denominator = 0.0

          denominator += math.exp(
        		  (b1 * x11) +
            (b2 * x12) +
            (b3 * x13) +
            (b4 * x14))
            
                  denominator += math.exp(
        		  (b1 * x21) +
            (b2 * x22) +
            (b3 * x23) +
            (b4 * x24))

        val result = numerator / denominator
        //println(result)
        result
      })
          a2.addPragma(Abstraction(10)) 
    val b1 = Binomial(start1,a1)
    b1.addPragma(Abstraction(10)(CounterAbstraction))
    val b2 = Binomial(start2,a2)

    val z1 = Counter(List(b1))
    val z2 = Counter(List(b2))

    val o1 = 42
    val o2 = 7
    
    z1.setConstraint((n: Int) => {
	      val result = poissonDensity(n,o1)//normalDensity(n.toDouble, birdsObservedInCell.toDouble, 0.55)
	      println("set constraint (c,n,o,r): " + " " + n + " " + o1 + " " + result)
	      result
	    })
	    
	  z2.setConstraint((n: Int) => {
	      val result = poissonDensity(n,o2)//normalDensity(n.toDouble, birdsObservedInCell.toDouble, 0.55)
	      println("set constraint (c,n,o,r): " + " " + n + " " + o2 + " " + result)
	      result
	    })
    
	    
	z1.addPragma(Abstraction(10)(CounterAbstraction))
	z2.addPragma(Abstraction(10)(CounterAbstraction))
	    
    val a3 = Apply(p1, p2, p3, p4, (b1: Double, b2: Double, b3: Double, b4: Double) => {

        val numerator = math.exp(
            (b1 * x31) +
            (b2 * x32) +
            (b3 * x33) +
            (b4 * x34))

        var denominator = 0.0

          denominator += math.exp(
        		  (b1 * x31) +
            (b2 * x32) +
            (b3 * x33) +
            (b4 * x34))
            
                  denominator += math.exp(
        		  (b1 * x41) +
            (b2 * x42) +
            (b3 * x43) +
            (b4 * x44))

        val result = numerator / denominator
        //println(result)
        result
      })
	  a3.addPragma(Abstraction(10)) 
	  val a4 = Apply(p1, p2, p3, p4, (b1: Double, b2: Double, b3: Double, b4: Double) => {

        val numerator = math.exp(
            (b1 * x41) +
            (b2 * x42) +
            (b3 * x43) +
            (b4 * x44))

        var denominator = 0.0

          denominator += math.exp(
        		  (b1 * x31) +
            (b2 * x32) +
            (b3 * x33) +
            (b4 * x34))
            
                  denominator += math.exp(
        		  (b1 * x41) +
            (b2 * x42) +
            (b3 * x43) +
            (b4 * x44))

        val result = numerator / denominator
        //println(result)
        result
      }) 
      a4.addPragma(Abstraction(10)) 
      
    val b3 = Binomial(z1,a3)
    b3.addPragma(Abstraction(10)(CounterAbstraction))
    val b4 = Binomial(z2,a4)

    val z3 = Counter(List(b3))
    val z4 = Counter(List(b4))

    val o3 = 0
    val o4 = 0
    /*
    z3.setConstraint((n: Int) => {
	      val result = poissonDensity(n,o3)//normalDensity(n.toDouble, birdsObservedInCell.toDouble, 0.55)
	      println("set constraint (c,n,o,r): " + " " + n + " " + o3 + " " + result)
	      result
	    })
	    
	  z4.setConstraint((n: Int) => {
	      val result = poissonDensity(n,o4)//normalDensity(n.toDouble, birdsObservedInCell.toDouble, 0.55)
	      println("set constraint (c,n,o,r): " + " " + n + " " + o4 + " " + result)
	      result
	    })
      */
    val t = List(p1,p2,p3,p4,a1,a2,a3,a4,b1,b2,z1,z2,z3,z4)

    val inferenceAlgorithm = BeliefPropagation.lazyBP(10,10000,false,t:_*)
    //val inferenceAlgorithm = VariableElimination(t:_*)
    inferenceAlgorithm.start
    val e1 = inferenceAlgorithm.expectation(p1, (d1:Double) => d1)
    println(e1)
    val e2 = inferenceAlgorithm.expectation(p2, (d1:Double) => d1)
    println(e2)
    val e3 = inferenceAlgorithm.expectation(p3, (d1:Double) => d1)
    println(e3)
    val e4 = inferenceAlgorithm.expectation(p4, (d1:Double) => d1)
    println(e4)
    inferenceAlgorithm.stop
    inferenceAlgorithm.kill
  }

  def main(args: Array[String]) : Unit = {
    constraintTest1
  }
}