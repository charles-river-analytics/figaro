package com.cra.appril.birdmigration

import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.language.Apply
import com.cra.figaro.library.atomic._
import com.cra.appril.birdmigration.data.io.DataReader
import com.cra.appril.birdmigration.model.Model
import com.cra.appril.birdmigration.model.ModelData
import com.cra.figaro.algorithm.factored.beliefpropagation.BeliefPropagation
import com.cra.figaro.algorithm.Abstraction
import com.cra.figaro.library.atomic.continuous.Normal

class Main {

}

object Main {
  

  def testNew = {
    val x1 = discrete.Uniform(2.0,4.0,6.0)
    val a1 = Apply(x1,(d1:Double) => d1*2.0)
    val a2 = Apply(x1,(d1:Double) => d1*2.0)
    //a1.observe(4.0)//Expectation of 2.0
    //a2.observe(12.0)//This line will result in an expectation of 0 or NaN
    val t = List(a1,x1)
    val inferenceAlgorithm = BeliefPropagation.lazyBP(10,100,false,t:_*)
    //val inferenceAlgorithm = VariableElimination(t:_*)
    inferenceAlgorithm.start
    val e = inferenceAlgorithm.expectation(x1, (d1:Double) => d1)
    println(e)
    inferenceAlgorithm.stop
    inferenceAlgorithm.kill
  }
  
  def main(): Unit = {


    //val observationsFileName = "onebird-observations.csv"
    //val featuresFileName = "onebird_features.csv"
    
    
    val observationsFileName = "R:/BirdModel/cp2-birdcast-v1/onebird/onebird-observations.csv"
    val featuresFileName = "R:/BirdModel/cp2-birdcast-v1/onebird/onebird_features_corrected.csv"
    
    //val observationsFileName = "10x10x1000000-train-observations.csv"
    //val featuresFileName = "10x10x1000000-train-features_corrected.csv"
    
    //val observationsFileName = "R:/BirdModel/cp2-birdcast-v1/millionbird/10x10x1000000-train-observations.csv"
    //val featuresFileName = "R:/BirdModel/cp2-birdcast-v1/millionbird/10x10x1000000-train-features_corrected.csv"
    val gridDimension = 4//How many cells to expect  
    val reader = DataReader(gridDimension)
    val birdsObservedInCell = reader.readObservationsFile(observationsFileName)
    val featureInCell = reader.readFeaturesFile(featuresFileName)

    
    //2
    val b1 = discrete.Uniform(0.25,0.50,0.75)
    val b2 = discrete.Uniform(0.25,0.50,0.75)
    val b3 = discrete.Uniform(0.25,0.50,0.75)
    val b4 = discrete.Uniform(0.25,0.50,0.75)
    
    //val b1 = Normal(0.50,0.15)
    //val b2 = Normal(0.50,0.15)
    //val b3 = Normal(0.50,0.15)
    //val b4 = Normal(0.50,0.15)
    //Make all of these parameters
    val numberOfBirds = 1
    val startDay = 1
    val endDay = 19//20 days, 19 nights.
    val startYear = 1
    val endYear = 2
   
    val data = ModelData(gridDimension, numberOfBirds, startDay,endDay,startYear,endYear,b1,b2,b3,b4,birdsObservedInCell,featureInCell)
    
    val model = Model(data)
    model.runEstimationTransition
    
   

  }
}