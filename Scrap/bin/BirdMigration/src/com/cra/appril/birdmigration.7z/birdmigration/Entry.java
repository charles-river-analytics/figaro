package com.cra.appril.birdmigration;

public class Entry {
	
	public static void main(String[] args) {
		Main.main();
	}
}
